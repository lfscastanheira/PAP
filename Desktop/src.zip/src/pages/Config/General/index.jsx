import { Container } from "../../../styles/AdminStyles";

const General = () => {
	return (
		<>
			<Container></Container>
		</>
	);
};

export default General;
