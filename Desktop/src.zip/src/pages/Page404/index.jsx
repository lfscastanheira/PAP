const Page404 = () => {
    return (
        <div>Page404</div>
    )
}

export default Page404